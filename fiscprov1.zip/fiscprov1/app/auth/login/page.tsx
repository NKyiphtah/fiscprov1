"use client"

import type React from "react"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Shield, Eye, EyeOff, ArrowLeft, AlertTriangle } from "lucide-react"
import Link from "next/link"

// Utilisateurs de démonstration
const demoUsers = [
  {
    email: "encodeur@finances.cd",
    password: "demo123",
    role: "Encodeur",
    nom: "Joseph MBUYI",
    centre: "Centre A",
  },
  {
    email: "chef.centre@finances.cd",
    password: "demo123",
    role: "Chef_Centre",
    nom: "Jean MUKENDI",
    centre: "Centre A",
  },
  {
    email: "chef.division@finances.cd",
    password: "demo123",
    role: "Chef_Division",
    nom: "Marie TSHISEKEDI",
    centre: null,
  },
  {
    email: "direction@finances.cd",
    password: "demo123",
    role: "Direction",
    nom: "Directeur des Finances",
    centre: null,
  },
]

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const roleParam = searchParams.get("role")

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    role: roleParam || "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Simulation d'authentification
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Vérifier les identifiants
    const user = demoUsers.find(
      (u) => u.email === formData.email && u.password === formData.password && u.role === formData.role,
    )

    if (user) {
      // Stocker les informations utilisateur
      localStorage.setItem(
        "user",
        JSON.stringify({
          email: user.email,
          role: user.role,
          nom: user.nom,
          centre: user.centre,
        }),
      )

      // Rediriger selon le rôle
      switch (user.role) {
        case "Encodeur":
          router.push("/encodeur")
          break
        case "Chef_Centre":
          router.push("/chef-centre")
          break
        case "Chef_Division":
          router.push("/chef-division")
          break
        case "Direction":
          router.push("/direction")
          break
        default:
          router.push("/dashboard")
      }
    } else {
      setError("Identifiants incorrects ou rôle non autorisé")
    }

    setIsLoading(false)
  }

  const loginAsDemo = (user: (typeof demoUsers)[0]) => {
    setFormData({
      email: user.email,
      password: user.password,
      role: user.role,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à l'accueil
          </Link>
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
              <Shield className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Connexion SGF-RDC</h1>
          <p className="text-gray-600">Accédez au système de gestion fiscale</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Se Connecter</CardTitle>
            <CardDescription>Entrez vos identifiants pour accéder au système</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="votre.email@finances.cd"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Mot de passe</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Votre mot de passe"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="role">Rôle</Label>
                <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner votre rôle" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Encodeur">Encodeur</SelectItem>
                    <SelectItem value="Chef_Centre">Chef de Centre</SelectItem>
                    <SelectItem value="Chef_Division">Chef de Division</SelectItem>
                    <SelectItem value="Direction">Direction</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Connexion..." : "Se Connecter"}
              </Button>
            </form>

            <div className="mt-6">
              <div className="text-center text-sm text-gray-600 mb-4">
                <span>Pas encore de compte ? </span>
                <Link href="/auth/register" className="text-blue-600 hover:text-blue-700 font-medium">
                  S'inscrire
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Comptes de démonstration */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-lg">Comptes de Démonstration</CardTitle>
            <CardDescription>Cliquez sur un rôle pour vous connecter automatiquement</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3">
              {demoUsers.map((user, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="justify-between h-auto p-4 bg-transparent"
                  onClick={() => loginAsDemo(user)}
                >
                  <div className="text-left">
                    <div className="font-medium">{user.nom}</div>
                    <div className="text-sm text-gray-500">{user.email}</div>
                  </div>
                  <Badge
                    variant="secondary"
                    className={
                      user.role === "Direction"
                        ? "bg-yellow-100 text-yellow-800"
                        : user.role === "Chef_Division"
                          ? "bg-purple-100 text-purple-800"
                          : user.role === "Chef_Centre"
                            ? "bg-green-100 text-green-800"
                            : "bg-blue-100 text-blue-800"
                    }
                  >
                    {user.role.replace("_", " ")}
                  </Badge>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
