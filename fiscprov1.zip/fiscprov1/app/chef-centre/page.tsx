"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { Users, DollarSign, TrendingUp, AlertTriangle, Download, Mail, Eye, FileText, Target } from "lucide-react"

// Ajouter les imports nécessaires en haut du fichier
import { ProtectedRoute } from "@/components/protected-route"
import { UserMenu } from "@/components/user-menu"

// Données simulées pour le Centre A
const statsCentre = {
  contribuables: 45,
  declarationsEnCours: 12,
  montantOrdonnance: 85000,
  montantRecouvre: 78500,
  retardataires: 8,
  tauxRecouvrement: 92,
}

const performanceParImpot = [
  { type: "ICM", ordonnance: 35000, recouvre: 32000, taux: 91 },
  { type: "IRL", ordonnance: 25000, recouvre: 23500, taux: 94 },
  { type: "IF", ordonnance: 15000, recouvre: 13500, taux: 90 },
  { type: "Vignettes", ordonnance: 10000, recouvre: 9500, taux: 95 },
]

const contribuablesCentre = [
  {
    id: "CONT-001",
    nom: "MUKENDI KABONGO Jean",
    declarations: 3,
    montantDu: 2500,
    dernierPaiement: "2024-02-15",
    statut: "Actif",
  },
  {
    id: "CONT-002",
    nom: "TSHISEKEDI MBUYI Marie",
    declarations: 2,
    montantDu: 1800,
    dernierPaiement: "2024-02-20",
    statut: "Actif",
  },
  {
    id: "CONT-003",
    nom: "KABILA NGOY Pierre",
    declarations: 1,
    montantDu: 5600,
    dernierPaiement: "2024-01-10",
    statut: "Retard",
  },
]

const retardatairesCentre = [
  {
    id: "CONT-003",
    nom: "KABILA NGOY Pierre",
    type: "ICM",
    montant: 2500,
    retard: 45,
    dernierContact: "2024-02-01",
  },
  {
    id: "CONT-007",
    nom: "MBUYI KASONGO Paul",
    type: "IRL",
    montant: 1200,
    retard: 30,
    dernierContact: "2024-02-10",
  },
]

// Envelopper le contenu dans ProtectedRoute et ajouter UserMenu dans le header
export default function ChefCentreDashboard() {
  const [activeTab, setActiveTab] = useState("synthese")
  const [selectedPeriode, setSelectedPeriode] = useState("2024-02")

  const exportRapport = (format: string) => {
    console.log(`Export rapport Centre A en ${format}`)
  }

  const envoyerRelance = (contribuableId: string) => {
    console.log(`Relance envoyée à ${contribuableId}`)
  }

  return (
    <ProtectedRoute allowedRoles={["Chef_Centre"]}>
      <div className="min-h-screen bg-slate-50">
        {/* Header Chef de Centre */}
        <header className="bg-green-900 text-white p-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold">Interface Chef de Centre</h1>
                <p className="text-green-200">Centre A - Gestion et supervision</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-sm text-green-200">Connecté en tant que</p>
                  <p className="font-semibold">Jean MUKENDI - Chef de Centre A</p>
                </div>
                <UserMenu />
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="synthese">Synthèse</TabsTrigger>
              <TabsTrigger value="contribuables">Contribuables</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="retardataires">Retardataires</TabsTrigger>
              <TabsTrigger value="rapports">Rapports</TabsTrigger>
            </TabsList>

            {/* Synthèse du Centre */}
            <TabsContent value="synthese" className="space-y-6">
              {/* KPIs du Centre */}
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Contribuables</p>
                        <p className="text-2xl font-bold">{statsCentre.contribuables}</p>
                      </div>
                      <Users className="h-8 w-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Déclarations</p>
                        <p className="text-2xl font-bold">{statsCentre.declarationsEnCours}</p>
                      </div>
                      <FileText className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Ordonnancé</p>
                        <p className="text-xl font-bold">${statsCentre.montantOrdonnance.toLocaleString()}</p>
                      </div>
                      <DollarSign className="h-8 w-8 text-yellow-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Recouvré</p>
                        <p className="text-xl font-bold text-green-600">
                          ${statsCentre.montantRecouvre.toLocaleString()}
                        </p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Taux</p>
                        <p className="text-2xl font-bold text-blue-600">{statsCentre.tauxRecouvrement}%</p>
                      </div>
                      <Target className="h-8 w-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Retardataires</p>
                        <p className="text-2xl font-bold text-red-600">{statsCentre.retardataires}</p>
                      </div>
                      <AlertTriangle className="h-8 w-8 text-red-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Graphiques de performance */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance par Type d'Impôt</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={performanceParImpot}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="type" />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                        <Bar dataKey="ordonnance" fill="#3b82f6" name="Ordonnancé" />
                        <Bar dataKey="recouvre" fill="#10b981" name="Recouvré" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Répartition des Recettes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={performanceParImpot}
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="recouvre"
                          label={({ type, percent }) => `${type} ${(percent * 100).toFixed(0)}%`}
                        >
                          {performanceParImpot.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={["#3b82f6", "#10b981", "#f59e0b", "#ef4444"][index]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Objectifs vs Réalisations */}
              <Card>
                <CardHeader>
                  <CardTitle>Objectifs vs Réalisations - Centre A</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {performanceParImpot.map((item, index) => (
                      <div key={index}>
                        <div className="flex justify-between mb-2">
                          <span className="font-medium">{item.type}</span>
                          <span className="text-sm text-muted-foreground">{item.taux}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-3">
                          <div
                            className="bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all duration-300"
                            style={{ width: `${item.taux}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Contribuables du Centre */}
            <TabsContent value="contribuables">
              <Card>
                <CardHeader>
                  <CardTitle>Contribuables du Centre A</CardTitle>
                  <CardDescription>Gestion des contribuables de votre centre</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 mb-4">
                    <Input placeholder="Rechercher un contribuable..." className="max-w-sm" />
                    <Select>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Filtrer par statut" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="tous">Tous les statuts</SelectItem>
                        <SelectItem value="actif">Actif</SelectItem>
                        <SelectItem value="retard">En retard</SelectItem>
                        <SelectItem value="suspendu">Suspendu</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nom Complet</TableHead>
                        <TableHead>Déclarations</TableHead>
                        <TableHead>Montant Dû</TableHead>
                        <TableHead>Dernier Paiement</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {contribuablesCentre.map((contribuable) => (
                        <TableRow key={contribuable.id}>
                          <TableCell className="font-medium">{contribuable.id}</TableCell>
                          <TableCell>{contribuable.nom}</TableCell>
                          <TableCell>{contribuable.declarations}</TableCell>
                          <TableCell className="font-semibold">${contribuable.montantDu.toLocaleString()}</TableCell>
                          <TableCell>{contribuable.dernierPaiement}</TableCell>
                          <TableCell>
                            <Badge
                              variant={contribuable.statut === "Actif" ? "default" : "destructive"}
                              className={contribuable.statut === "Actif" ? "bg-green-100 text-green-800" : ""}
                            >
                              {contribuable.statut}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="outline" size="sm">
                                <FileText className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Performance */}
            <TabsContent value="performance">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Analyse de Performance - Centre A</CardTitle>
                    <CardDescription>Détail des performances par type d'impôt</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Type d'Impôt</TableHead>
                          <TableHead>Ordonnancé</TableHead>
                          <TableHead>Recouvré</TableHead>
                          <TableHead>Écart</TableHead>
                          <TableHead>Taux</TableHead>
                          <TableHead>Évaluation</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {performanceParImpot.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{item.type}</TableCell>
                            <TableCell>${item.ordonnance.toLocaleString()}</TableCell>
                            <TableCell className="text-green-600 font-semibold">
                              ${item.recouvre.toLocaleString()}
                            </TableCell>
                            <TableCell>${(item.ordonnance - item.recouvre).toLocaleString()}</TableCell>
                            <TableCell className="font-semibold">{item.taux}%</TableCell>
                            <TableCell>
                              <Badge
                                variant={item.taux >= 90 ? "default" : item.taux >= 80 ? "secondary" : "destructive"}
                                className={
                                  item.taux >= 90
                                    ? "bg-green-100 text-green-800"
                                    : item.taux >= 80
                                      ? "bg-yellow-100 text-yellow-800"
                                      : ""
                                }
                              >
                                {item.taux >= 90 ? "Excellent" : item.taux >= 80 ? "Bon" : "À améliorer"}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Retardataires */}
            <TabsContent value="retardataires">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-500" />
                    Contribuables en Retard - Centre A
                  </CardTitle>
                  <CardDescription>Gestion des relances et suivi des retards</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nom</TableHead>
                        <TableHead>Type d'Impôt</TableHead>
                        <TableHead>Montant Dû</TableHead>
                        <TableHead>Retard (jours)</TableHead>
                        <TableHead>Dernier Contact</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {retardatairesCentre.map((retardataire) => (
                        <TableRow key={retardataire.id}>
                          <TableCell className="font-medium">{retardataire.id}</TableCell>
                          <TableCell>{retardataire.nom}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{retardataire.type}</Badge>
                          </TableCell>
                          <TableCell className="font-semibold text-red-600">
                            ${retardataire.montant.toLocaleString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant="destructive">{retardataire.retard} jours</Badge>
                          </TableCell>
                          <TableCell>{retardataire.dernierContact}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" onClick={() => envoyerRelance(retardataire.id)}>
                                <Mail className="h-4 w-4 mr-1" />
                                Relancer
                              </Button>
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Rapports */}
            <TabsContent value="rapports">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Génération de Rapports - Centre A</CardTitle>
                    <CardDescription>Export des données et rapports de performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="font-semibold">Rapports Disponibles</h3>
                        <div className="space-y-2">
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapport("PDF")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Rapport Mensuel (PDF)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapport("Excel")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Données Contribuables (Excel)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapport("PDF")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Liste Retardataires (PDF)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapport("Excel")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Performance par Impôt (Excel)
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h3 className="font-semibold">Paramètres d'Export</h3>
                        <div className="space-y-2">
                          <div>
                            <label className="text-sm font-medium">Période</label>
                            <Select value={selectedPeriode} onValueChange={setSelectedPeriode}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="2024-02">Février 2024</SelectItem>
                                <SelectItem value="2024-01">Janvier 2024</SelectItem>
                                <SelectItem value="2023-12">Décembre 2023</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ProtectedRoute>
  )
}
