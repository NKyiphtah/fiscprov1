"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts"
import { Crown, Users, DollarSign, Target, Building2, Download, BarChart3 } from "lucide-react"

// Ajouter les imports nécessaires en haut du fichier
import { ProtectedRoute } from "@/components/protected-route"
import { UserMenu } from "@/components/user-menu"

// Données stratégiques pour la Direction
const statsStrategiques = {
  recettesTotales: 2850000,
  objectifAnnuel: 3200000,
  tauxRealisationObjectif: 89,
  croissanceAnnuelle: 12.5,
  nombreCentres: 3,
  nombreContribuables: 1250,
  recettesMoyennesParContribuable: 2280,
}

const comparaisonBudgetaire = [
  { periode: "2022", prevision: 2800000, realisation: 2650000, taux: 95 },
  { periode: "2023", prevision: 3000000, realisation: 2850000, taux: 95 },
  { periode: "2024", prevision: 3200000, realisation: 2850000, taux: 89 },
]

const evolutionTrimestrielle = [
  { trimestre: "T1 2023", recettes: 680000, objectif: 720000 },
  { trimestre: "T2 2023", recettes: 720000, objectif: 750000 },
  { trimestre: "T3 2023", recettes: 750000, objectif: 765000 },
  { trimestre: "T4 2023", recettes: 700000, objectif: 765000 },
  { trimestre: "T1 2024", recettes: 712500, objectif: 800000 },
]

const performanceParDivision = [
  { division: "Division Kinshasa", recettes: 1425000, objectif: 1600000, taux: 89 },
  { division: "Division Lubumbashi", recettes: 855000, objectif: 960000, taux: 89 },
  { division: "Division Mbuji-Mayi", recettes: 570000, objectif: 640000, taux: 89 },
]

const indicateursStrategiques = [
  { indicateur: "Taux de Digitalisation", valeur: 75, objectif: 85, unite: "%" },
  { indicateur: "Délai Moyen de Traitement", valeur: 3.2, objectif: 2.5, unite: "jours" },
  { indicateur: "Satisfaction Contribuables", valeur: 82, objectif: 90, unite: "%" },
  { indicateur: "Efficacité Recouvrement", valeur: 91, objectif: 95, unite: "%" },
]

// Envelopper le contenu dans ProtectedRoute et ajouter UserMenu dans le header
export default function DirectionDashboard() {
  const [activeTab, setActiveTab] = useState("vue-strategique")
  const [selectedAnnee, setSelectedAnnee] = useState("2024")

  const exportRapportStrategique = (format: string) => {
    console.log(`Export rapport stratégique en ${format}`)
  }

  return (
    <ProtectedRoute allowedRoles={["Direction"]}>
      <div className="min-h-screen bg-slate-50">
        {/* Header Direction */}
        <header className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold flex items-center gap-3">
                  <Crown className="h-8 w-8 text-yellow-400" />
                  Direction des Finances
                </h1>
                <p className="text-slate-300">Vue stratégique et pilotage global - République Démocratique du Congo</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-sm text-slate-300">Connecté en tant que</p>
                  <p className="font-semibold text-lg">Directeur des Finances</p>
                  <Badge className="bg-yellow-600 text-white mt-1">Direction Générale</Badge>
                </div>
                <UserMenu />
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="vue-strategique">Vue Stratégique</TabsTrigger>
              <TabsTrigger value="budget">Budget & Objectifs</TabsTrigger>
              <TabsTrigger value="divisions">Divisions</TabsTrigger>
              <TabsTrigger value="indicateurs">Indicateurs</TabsTrigger>
              <TabsTrigger value="rapports-direction">Rapports</TabsTrigger>
            </TabsList>

            {/* Vue Stratégique */}
            <TabsContent value="vue-strategique" className="space-y-6">
              {/* KPIs Stratégiques */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="border-l-4 border-l-blue-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Recettes Totales</p>
                        <p className="text-3xl font-bold text-blue-600">
                          ${(statsStrategiques.recettesTotales / 1000000).toFixed(1)}M
                        </p>
                        <p className="text-sm text-green-600">+{statsStrategiques.croissanceAnnuelle}% vs 2023</p>
                      </div>
                      <DollarSign className="h-12 w-12 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-green-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Réalisation Objectif</p>
                        <p className="text-3xl font-bold text-green-600">
                          {statsStrategiques.tauxRealisationObjectif}%
                        </p>
                        <p className="text-sm text-muted-foreground">
                          ${(statsStrategiques.objectifAnnuel / 1000000).toFixed(1)}M objectif
                        </p>
                      </div>
                      <Target className="h-12 w-12 text-green-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-purple-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Contribuables</p>
                        <p className="text-3xl font-bold text-purple-600">{statsStrategiques.nombreContribuables}</p>
                        <p className="text-sm text-muted-foreground">
                          ${statsStrategiques.recettesMoyennesParContribuable} moy/contrib
                        </p>
                      </div>
                      <Users className="h-12 w-12 text-purple-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-orange-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Divisions</p>
                        <p className="text-3xl font-bold text-orange-600">{statsStrategiques.nombreCentres}</p>
                        <p className="text-sm text-green-600">Performance moyenne: 89%</p>
                      </div>
                      <Building2 className="h-12 w-12 text-orange-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Graphiques stratégiques */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Évolution Trimestrielle des Recettes</CardTitle>
                    <CardDescription>Performance vs objectifs par trimestre</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={evolutionTrimestrielle}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="trimestre" />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${(value / 1000).toFixed(0)}K`} />
                        <Area
                          type="monotone"
                          dataKey="objectif"
                          stackId="1"
                          stroke="#ef4444"
                          fill="#fecaca"
                          name="Objectif"
                        />
                        <Area
                          type="monotone"
                          dataKey="recettes"
                          stackId="2"
                          stroke="#10b981"
                          fill="#86efac"
                          name="Réalisé"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Performance par Division</CardTitle>
                    <CardDescription>Répartition géographique des recettes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={performanceParDivision} layout="horizontal">
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="division" type="category" width={120} />
                        <Tooltip formatter={(value) => `$${(value / 1000).toFixed(0)}K`} />
                        <Bar dataKey="objectif" fill="#e5e7eb" name="Objectif" />
                        <Bar dataKey="recettes" fill="#3b82f6" name="Réalisé" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Tableau de bord exécutif */}
              <Card>
                <CardHeader>
                  <CardTitle>Tableau de Bord Exécutif</CardTitle>
                  <CardDescription>Indicateurs clés de performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {indicateursStrategiques.map((indicateur, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <h4 className="font-semibold text-sm mb-2">{indicateur.indicateur}</h4>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-2xl font-bold">
                            {indicateur.valeur}
                            {indicateur.unite}
                          </span>
                          <Badge variant={indicateur.valeur >= indicateur.objectif ? "default" : "secondary"}>
                            {indicateur.valeur >= indicateur.objectif ? "✓" : "⚠"}
                          </Badge>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              indicateur.valeur >= indicateur.objectif ? "bg-green-500" : "bg-yellow-500"
                            }`}
                            style={{ width: `${Math.min((indicateur.valeur / indicateur.objectif) * 100, 100)}%` }}
                          ></div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Objectif: {indicateur.objectif}
                          {indicateur.unite}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Budget & Objectifs */}
            <TabsContent value="budget">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Comparaison Budgétaire Pluriannuelle</CardTitle>
                    <CardDescription>Évolution des prévisions vs réalisations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={comparaisonBudgetaire}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="periode" />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${(value / 1000000).toFixed(1)}M`} />
                        <Bar dataKey="prevision" fill="#94a3b8" name="Prévision" />
                        <Bar dataKey="realisation" fill="#3b82f6" name="Réalisation" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Analyse Budgétaire Détaillée</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Période</TableHead>
                          <TableHead>Prévision</TableHead>
                          <TableHead>Réalisation</TableHead>
                          <TableHead>Écart</TableHead>
                          <TableHead>Taux</TableHead>
                          <TableHead>Évaluation</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {comparaisonBudgetaire.map((budget, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{budget.periode}</TableCell>
                            <TableCell>${(budget.prevision / 1000000).toFixed(1)}M</TableCell>
                            <TableCell className="text-blue-600 font-semibold">
                              ${(budget.realisation / 1000000).toFixed(1)}M
                            </TableCell>
                            <TableCell
                              className={budget.realisation >= budget.prevision ? "text-green-600" : "text-red-600"}
                            >
                              ${((budget.realisation - budget.prevision) / 1000000).toFixed(1)}M
                            </TableCell>
                            <TableCell className="font-semibold">{budget.taux}%</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  budget.taux >= 95 ? "default" : budget.taux >= 85 ? "secondary" : "destructive"
                                }
                              >
                                {budget.taux >= 95 ? "Excellent" : budget.taux >= 85 ? "Satisfaisant" : "À améliorer"}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Divisions */}
            <TabsContent value="divisions">
              <Card>
                <CardHeader>
                  <CardTitle>Performance des Divisions</CardTitle>
                  <CardDescription>Analyse comparative inter-divisions</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Division</TableHead>
                        <TableHead>Recettes</TableHead>
                        <TableHead>Objectif</TableHead>
                        <TableHead>Écart</TableHead>
                        <TableHead>Taux</TableHead>
                        <TableHead>Rang</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {performanceParDivision
                        .sort((a, b) => b.taux - a.taux)
                        .map((division, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{division.division}</TableCell>
                            <TableCell className="text-blue-600 font-semibold">
                              ${(division.recettes / 1000000).toFixed(1)}M
                            </TableCell>
                            <TableCell>${(division.objectif / 1000000).toFixed(1)}M</TableCell>
                            <TableCell
                              className={division.recettes >= division.objectif ? "text-green-600" : "text-red-600"}
                            >
                              ${((division.recettes - division.objectif) / 1000000).toFixed(1)}M
                            </TableCell>
                            <TableCell className="font-semibold">{division.taux}%</TableCell>
                            <TableCell>
                              <Badge variant="outline">#{index + 1}</Badge>
                            </TableCell>
                            <TableCell>
                              <Button variant="outline" size="sm">
                                <BarChart3 className="h-4 w-4 mr-1" />
                                Analyser
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Indicateurs */}
            <TabsContent value="indicateurs">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Indicateurs de Performance Stratégiques</CardTitle>
                    <CardDescription>Suivi des KPIs critiques</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {indicateursStrategiques.map((indicateur, index) => (
                        <Card key={index} className="p-4">
                          <div className="flex justify-between items-start mb-4">
                            <h3 className="font-semibold">{indicateur.indicateur}</h3>
                            <Badge variant={indicateur.valeur >= indicateur.objectif ? "default" : "secondary"}>
                              {indicateur.valeur >= indicateur.objectif ? "Atteint" : "En cours"}
                            </Badge>
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span>Actuel:</span>
                              <span className="font-bold">
                                {indicateur.valeur}
                                {indicateur.unite}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span>Objectif:</span>
                              <span>
                                {indicateur.objectif}
                                {indicateur.unite}
                              </span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-3">
                              <div
                                className={`h-3 rounded-full transition-all duration-300 ${
                                  indicateur.valeur >= indicateur.objectif ? "bg-green-500" : "bg-yellow-500"
                                }`}
                                style={{ width: `${Math.min((indicateur.valeur / indicateur.objectif) * 100, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Rapports Direction */}
            <TabsContent value="rapports-direction">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Rapports Stratégiques</CardTitle>
                    <CardDescription>Export des analyses et tableaux de bord exécutifs</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="font-semibold">Rapports Exécutifs</h3>
                        <div className="space-y-2">
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapportStrategique("PDF")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Tableau de Bord Exécutif (PDF)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapportStrategique("Excel")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Analyse Budgétaire (Excel)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapportStrategique("PDF")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Performance Divisions (PDF)
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start bg-transparent"
                            onClick={() => exportRapportStrategique("Excel")}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Données Consolidées (Excel)
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h3 className="font-semibold">Paramètres</h3>
                        <div className="space-y-2">
                          <div>
                            <label className="text-sm font-medium">Année</label>
                            <Select value={selectedAnnee} onValueChange={setSelectedAnnee}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="2024">2024</SelectItem>
                                <SelectItem value="2023">2023</SelectItem>
                                <SelectItem value="2022">2022</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div className="space-y-3 mt-6">
                          <h4 className="font-semibold">Résumé Exécutif</h4>
                          <div className="space-y-2">
                            <div className="flex justify-between p-3 bg-blue-50 rounded-lg">
                              <span>Performance Globale:</span>
                              <span className="font-semibold">89%</span>
                            </div>
                            <div className="flex justify-between p-3 bg-green-50 rounded-lg">
                              <span>Croissance:</span>
                              <span className="font-semibold">+12.5%</span>
                            </div>
                            <div className="flex justify-between p-3 bg-purple-50 rounded-lg">
                              <span>Meilleure Division:</span>
                              <span className="font-semibold">Kinshasa</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ProtectedRoute>
  )
}
