"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Search, Plus, Edit, Eye, DollarSign, FileText, AlertTriangle } from "lucide-react"

interface NoteTaxation {
  id: number
  created_at: string
  type_impot: string
  montant_ordonnace: number
  numero_note: string
  numero_bordereau: string
  banque: string
  montant: number
}

const notesData: NoteTaxation[] = [
  {
    id: 1,
    created_at: "2024-01-15T10:30:00Z",
    type_impot: "ICM",
    montant_ordonnace: 1500.0,
    numero_note: "NOTE-2024-001",
    numero_bordereau: "BOR-2024-001",
    banque: "Rawbank",
    montant: 1500.0,
  },
  {
    id: 2,
    created_at: "2024-01-20T14:15:00Z",
    type_impot: "Penalite",
    montant_ordonnace: 250.0,
    numero_note: "NOTE-2024-002",
    numero_bordereau: "BOR-2024-002",
    banque: "BCC",
    montant: 200.0,
  },
  {
    id: 3,
    created_at: "2024-02-01T09:45:00Z",
    type_impot: "Frais",
    montant_ordonnace: 100.0,
    numero_note: "NOTE-2024-003",
    numero_bordereau: "BOR-2024-003",
    banque: "Equity Bank",
    montant: 100.0,
  },
]

export default function NotesTaxationPage() {
  const [notes, setNotes] = useState<NoteTaxation[]>(notesData)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedType, setSelectedType] = useState("tous")
  const [selectedBanque, setSelectedBanque] = useState("tous")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newNote, setNewNote] = useState({
    type_impot: "",
    montant_ordonnace: "",
    numero_note: "",
    numero_bordereau: "",
    banque: "",
    montant: "",
  })

  const filteredNotes = notes.filter((note) => {
    const matchesSearch =
      note.numero_note.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.numero_bordereau.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.banque.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesType = selectedType === "tous" || note.type_impot === selectedType
    const matchesBanque = selectedBanque === "tous" || note.banque === selectedBanque

    return matchesSearch && matchesType && matchesBanque
  })

  const handleAddNote = () => {
    const note: NoteTaxation = {
      id: notes.length + 1,
      created_at: new Date().toISOString(),
      type_impot: newNote.type_impot,
      montant_ordonnace: Number.parseFloat(newNote.montant_ordonnace) || 0,
      numero_note: newNote.numero_note,
      numero_bordereau: newNote.numero_bordereau,
      banque: newNote.banque,
      montant: Number.parseFloat(newNote.montant) || 0,
    }

    setNotes([...notes, note])
    setNewNote({
      type_impot: "",
      montant_ordonnace: "",
      numero_note: "",
      numero_bordereau: "",
      banque: "",
      montant: "",
    })
    setIsAddDialogOpen(false)
  }

  const getTypeImpotBadge = (type: string) => {
    const colors = {
      ICM: "bg-blue-100 text-blue-800",
      IRL: "bg-green-100 text-green-800",
      IF: "bg-yellow-100 text-yellow-800",
      Vignettes: "bg-purple-100 text-purple-800",
      Penalite: "bg-red-100 text-red-800",
      Frais: "bg-gray-100 text-gray-800",
    }
    return <Badge className={colors[type as keyof typeof colors] || "bg-gray-100 text-gray-800"}>{type}</Badge>
  }

  const getStatutPaiement = (ordonnance: number, recouvre: number) => {
    if (recouvre >= ordonnance) {
      return <Badge className="bg-green-100 text-green-800">Soldé</Badge>
    }
    if (recouvre > 0) {
      return <Badge className="bg-yellow-100 text-yellow-800">Partiel</Badge>
    }
    return <Badge variant="destructive">En attente</Badge>
  }

  const totalOrdonnance = notes.reduce((sum, note) => sum + note.montant_ordonnace, 0)
  const totalRecouvre = notes.reduce((sum, note) => sum + note.montant, 0)
  const tauxRecouvrement = totalOrdonnance > 0 ? Math.round((totalRecouvre / totalOrdonnance) * 100) : 0

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-900 text-white p-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold">Notes de Taxation</h1>
          <p className="text-slate-300">Gestion des recouvrements ponctuels divers</p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Statistiques */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Notes</p>
                  <p className="text-2xl font-bold">{notes.length}</p>
                </div>
                <FileText className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Ordonnancé</p>
                  <p className="text-2xl font-bold">${totalOrdonnance.toLocaleString()}</p>
                </div>
                <DollarSign className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Recouvré</p>
                  <p className="text-2xl font-bold text-green-600">${totalRecouvre.toLocaleString()}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Taux Recouvrement</p>
                  <p className="text-2xl font-bold text-blue-600">{tauxRecouvrement}%</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filtres et actions */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Recherche et Filtres</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher une note..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger>
                  <SelectValue placeholder="Tous les types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tous">Tous les types</SelectItem>
                  <SelectItem value="ICM">ICM</SelectItem>
                  <SelectItem value="IRL">IRL</SelectItem>
                  <SelectItem value="IF">IF</SelectItem>
                  <SelectItem value="Vignettes">Vignettes</SelectItem>
                  <SelectItem value="Penalite">Pénalité</SelectItem>
                  <SelectItem value="Frais">Frais</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedBanque} onValueChange={setSelectedBanque}>
                <SelectTrigger>
                  <SelectValue placeholder="Toutes les banques" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tous">Toutes les banques</SelectItem>
                  <SelectItem value="BCC">BCC</SelectItem>
                  <SelectItem value="Rawbank">Rawbank</SelectItem>
                  <SelectItem value="Equity Bank">Equity Bank</SelectItem>
                  <SelectItem value="TMB">TMB</SelectItem>
                  <SelectItem value="BCDC">BCDC</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline">Exporter</Button>

              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Nouvelle Note
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Ajouter une Note de Taxation</DialogTitle>
                    <DialogDescription>Saisir les informations de la note de taxation</DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="type_impot">Type d'Impôt</Label>
                      <Select
                        value={newNote.type_impot}
                        onValueChange={(value) => setNewNote({ ...newNote, type_impot: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner le type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ICM">ICM</SelectItem>
                          <SelectItem value="IRL">IRL</SelectItem>
                          <SelectItem value="IF">IF</SelectItem>
                          <SelectItem value="Vignettes">Vignettes</SelectItem>
                          <SelectItem value="Penalite">Pénalité</SelectItem>
                          <SelectItem value="Frais">Frais de dossier</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="numero_note">Numéro de Note</Label>
                      <Input
                        id="numero_note"
                        value={newNote.numero_note}
                        onChange={(e) => setNewNote({ ...newNote, numero_note: e.target.value })}
                        placeholder="NOTE-2024-001"
                      />
                    </div>
                    <div>
                      <Label htmlFor="numero_bordereau">Numéro de Bordereau</Label>
                      <Input
                        id="numero_bordereau"
                        value={newNote.numero_bordereau}
                        onChange={(e) => setNewNote({ ...newNote, numero_bordereau: e.target.value })}
                        placeholder="BOR-2024-001"
                      />
                    </div>
                    <div>
                      <Label htmlFor="banque">Banque</Label>
                      <Select
                        value={newNote.banque}
                        onValueChange={(value) => setNewNote({ ...newNote, banque: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner la banque" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="BCC">Banque Centrale du Congo</SelectItem>
                          <SelectItem value="Rawbank">Rawbank</SelectItem>
                          <SelectItem value="Equity Bank">Equity Bank</SelectItem>
                          <SelectItem value="TMB">Trust Merchant Bank</SelectItem>
                          <SelectItem value="BCDC">BCDC</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="montant_ordonnace">Montant Ordonnancé ($)</Label>
                      <Input
                        id="montant_ordonnace"
                        type="number"
                        step="0.01"
                        value={newNote.montant_ordonnace}
                        onChange={(e) => setNewNote({ ...newNote, montant_ordonnace: e.target.value })}
                        placeholder="0.00"
                      />
                    </div>
                    <div>
                      <Label htmlFor="montant">Montant Recouvré ($)</Label>
                      <Input
                        id="montant"
                        type="number"
                        step="0.01"
                        value={newNote.montant}
                        onChange={(e) => setNewNote({ ...newNote, montant: e.target.value })}
                        placeholder="0.00"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 mt-4">
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                      Annuler
                    </Button>
                    <Button onClick={handleAddNote}>Ajouter</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Tableau des notes */}
        <Card>
          <CardHeader>
            <CardTitle>Liste des Notes de Taxation ({filteredNotes.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>N° Note</TableHead>
                  <TableHead>N° Bordereau</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Banque</TableHead>
                  <TableHead>Ordonnancé</TableHead>
                  <TableHead>Recouvré</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredNotes.map((note) => (
                  <TableRow key={note.id}>
                    <TableCell className="font-medium">{note.numero_note}</TableCell>
                    <TableCell>{note.numero_bordereau}</TableCell>
                    <TableCell>{getTypeImpotBadge(note.type_impot)}</TableCell>
                    <TableCell>{note.banque}</TableCell>
                    <TableCell className="font-semibold">${note.montant_ordonnace.toLocaleString()}</TableCell>
                    <TableCell className="font-semibold text-green-600">${note.montant.toLocaleString()}</TableCell>
                    <TableCell>{getStatutPaiement(note.montant_ordonnace, note.montant)}</TableCell>
                    <TableCell>{new Date(note.created_at).toLocaleDateString("fr-FR")}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
