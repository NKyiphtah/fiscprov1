"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, FileText, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie } from "recharts"

// Données simulées pour les rapports
const rapportData = [
  {
    periode: "Janvier 2024",
    icm: { ordonnance: 45000, recouvre: 42000, taux: 93 },
    irl: { ordonnance: 32000, recouvre: 28000, taux: 88 },
    if: { ordonnance: 28000, recouvre: 25000, taux: 89 },
    vignettes: { ordonnance: 15000, recouvre: 14500, taux: 97 },
    total: { ordonnance: 120000, recouvre: 109500, taux: 91 },
  },
  {
    periode: "Février 2024",
    icm: { ordonnance: 48000, recouvre: 45000, taux: 94 },
    irl: { ordonnance: 35000, recouvre: 32000, taux: 91 },
    if: { ordonnance: 30000, recouvre: 27000, taux: 90 },
    vignettes: { ordonnance: 16000, recouvre: 15800, taux: 99 },
    total: { ordonnance: 129000, recouvre: 119800, taux: 93 },
  },
]

const retardatairesData = [
  {
    id: "CONT-001",
    nom: "MUKENDI KABONGO Jean",
    type: "ICM",
    montant: 1500,
    echeance: "2024-01-15",
    retard: 45,
    statut: "En relance",
  },
  {
    id: "CONT-003",
    nom: "KABILA NGOY Pierre",
    type: "IRL",
    montant: 2300,
    echeance: "2024-01-20",
    retard: 40,
    statut: "Première relance",
  },
  {
    id: "CONT-005",
    nom: "MBUYI TSHALA Joseph",
    type: "Vignette",
    montant: 158,
    echeance: "2024-02-01",
    retard: 18,
    statut: "Nouveau retard",
  },
]

const centrePerformance = [
  { centre: "Centre A", ordonnance: 45000, recouvre: 41000, taux: 91 },
  { centre: "Centre B", ordonnance: 52000, recouvre: 48000, taux: 92 },
  { centre: "Centre C", ordonnance: 38000, recouvre: 30000, taux: 79 },
]

export default function RapportsPage() {
  const [selectedPeriode, setSelectedPeriode] = useState("2024-02")
  const [selectedCentre, setSelectedCentre] = useState("tous")
  const [selectedType, setSelectedType] = useState("tous")

  const exportRapport = (format: string) => {
    console.log(`Export en ${format}`)
    // Logique d'export
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-900 text-white p-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold">Rapports et Statistiques</h1>
          <p className="text-slate-300">Analyse des performances fiscales</p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Filtres */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filtres de Rapport</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="periode">Période</Label>
                <Select value={selectedPeriode} onValueChange={setSelectedPeriode}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner la période" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024-01">Janvier 2024</SelectItem>
                    <SelectItem value="2024-02">Février 2024</SelectItem>
                    <SelectItem value="2024-03">Mars 2024</SelectItem>
                    <SelectItem value="2024-04">Avril 2024</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="centre">Centre</Label>
                <Select value={selectedCentre} onValueChange={setSelectedCentre}>
                  <SelectTrigger>
                    <SelectValue placeholder="Tous les centres" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tous">Tous les centres</SelectItem>
                    <SelectItem value="Centre A">Centre A</SelectItem>
                    <SelectItem value="Centre B">Centre B</SelectItem>
                    <SelectItem value="Centre C">Centre C</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="type">Type d'Impôt</Label>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Tous les types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tous">Tous les types</SelectItem>
                    <SelectItem value="ICM">ICM</SelectItem>
                    <SelectItem value="IRL">IRL</SelectItem>
                    <SelectItem value="IF">IF</SelectItem>
                    <SelectItem value="Vignettes">Vignettes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end gap-2">
                <Button onClick={() => exportRapport("PDF")} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  PDF
                </Button>
                <Button onClick={() => exportRapport("Excel")} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Excel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="synthese" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="synthese">Synthèse</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="retardataires">Retardataires</TabsTrigger>
            <TabsTrigger value="centres">Par Centre</TabsTrigger>
          </TabsList>

          <TabsContent value="synthese" className="space-y-6">
            {/* Statistiques principales */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Ordonnancé</p>
                      <p className="text-2xl font-bold">$129,000</p>
                    </div>
                    <FileText className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Recouvré</p>
                      <p className="text-2xl font-bold text-green-600">$119,800</p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Taux de Recouvrement</p>
                      <p className="text-2xl font-bold text-blue-600">93%</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Retardataires</p>
                      <p className="text-2xl font-bold text-red-600">3</p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-red-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Graphique de synthèse */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Performance par Type d'Impôt</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart
                      data={[
                        { name: "ICM", ordonnance: 48000, recouvre: 45000 },
                        { name: "IRL", ordonnance: 35000, recouvre: 32000 },
                        { name: "IF", ordonnance: 30000, recouvre: 27000 },
                        { name: "Vignettes", ordonnance: 16000, recouvre: 15800 },
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                      <Bar dataKey="ordonnance" fill="#3b82f6" name="Ordonnancé" />
                      <Bar dataKey="recouvre" fill="#10b981" name="Recouvré" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Répartition des Recettes</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={[
                          { name: "ICM", value: 45000, fill: "#3b82f6" },
                          { name: "IRL", value: 32000, fill: "#10b981" },
                          { name: "IF", value: 27000, fill: "#f59e0b" },
                          { name: "Vignettes", value: 15800, fill: "#ef4444" },
                        ]}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      />
                      <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Tableau détaillé */}
            <Card>
              <CardHeader>
                <CardTitle>Détail par Type d'Impôt</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type d'Impôt</TableHead>
                      <TableHead>Ordonnancé</TableHead>
                      <TableHead>Recouvré</TableHead>
                      <TableHead>Écart</TableHead>
                      <TableHead>Taux</TableHead>
                      <TableHead>Statut</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">ICM</TableCell>
                      <TableCell>$48,000</TableCell>
                      <TableCell>$45,000</TableCell>
                      <TableCell>$3,000</TableCell>
                      <TableCell>94%</TableCell>
                      <TableCell>
                        <Badge className="bg-green-100 text-green-800">Excellent</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">IRL</TableCell>
                      <TableCell>$35,000</TableCell>
                      <TableCell>$32,000</TableCell>
                      <TableCell>$3,000</TableCell>
                      <TableCell>91%</TableCell>
                      <TableCell>
                        <Badge className="bg-green-100 text-green-800">Bon</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">IF</TableCell>
                      <TableCell>$30,000</TableCell>
                      <TableCell>$27,000</TableCell>
                      <TableCell>$3,000</TableCell>
                      <TableCell>90%</TableCell>
                      <TableCell>
                        <Badge className="bg-green-100 text-green-800">Bon</Badge>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Vignettes</TableCell>
                      <TableCell>$16,000</TableCell>
                      <TableCell>$15,800</TableCell>
                      <TableCell>$200</TableCell>
                      <TableCell>99%</TableCell>
                      <TableCell>
                        <Badge className="bg-green-100 text-green-800">Excellent</Badge>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="retardataires">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                  Contribuables en Retard de Paiement
                </CardTitle>
                <CardDescription>Liste des contribuables ayant des paiements en retard</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Nom</TableHead>
                      <TableHead>Type d'Impôt</TableHead>
                      <TableHead>Montant Dû</TableHead>
                      <TableHead>Échéance</TableHead>
                      <TableHead>Retard (jours)</TableHead>
                      <TableHead>Statut</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {retardatairesData.map((retardataire) => (
                      <TableRow key={retardataire.id}>
                        <TableCell className="font-medium">{retardataire.id}</TableCell>
                        <TableCell>{retardataire.nom}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{retardataire.type}</Badge>
                        </TableCell>
                        <TableCell className="font-semibold">${retardataire.montant.toLocaleString()}</TableCell>
                        <TableCell>{retardataire.echeance}</TableCell>
                        <TableCell>
                          <Badge variant="destructive">{retardataire.retard} jours</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{retardataire.statut}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              Relancer
                            </Button>
                            <Button variant="outline" size="sm">
                              Détails
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="centres">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Performance par Centre</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={centrePerformance}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="centre" />
                      <YAxis />
                      <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                      <Bar dataKey="ordonnance" fill="#3b82f6" name="Ordonnancé" />
                      <Bar dataKey="recouvre" fill="#10b981" name="Recouvré" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Détail par Centre</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Centre</TableHead>
                        <TableHead>Ordonnancé</TableHead>
                        <TableHead>Recouvré</TableHead>
                        <TableHead>Écart</TableHead>
                        <TableHead>Taux</TableHead>
                        <TableHead>Performance</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {centrePerformance.map((centre) => (
                        <TableRow key={centre.centre}>
                          <TableCell className="font-medium">{centre.centre}</TableCell>
                          <TableCell>${centre.ordonnance.toLocaleString()}</TableCell>
                          <TableCell>${centre.recouvre.toLocaleString()}</TableCell>
                          <TableCell>${(centre.ordonnance - centre.recouvre).toLocaleString()}</TableCell>
                          <TableCell>{centre.taux}%</TableCell>
                          <TableCell>
                            <Badge
                              variant={centre.taux >= 90 ? "default" : centre.taux >= 80 ? "secondary" : "destructive"}
                            >
                              {centre.taux >= 90 ? "Excellent" : centre.taux >= 80 ? "Bon" : "À améliorer"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
