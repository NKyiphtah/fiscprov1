"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

interface RoleBasedLayoutProps {
  children: React.ReactNode
  allowedRoles: string[]
  currentUserRole?: string
}

export function RoleBasedLayout({ children, allowedRoles, currentUserRole = "Direction" }: RoleBasedLayoutProps) {
  const router = useRouter()
  const [hasAccess, setHasAccess] = useState(false)

  useEffect(() => {
    // Vérifier si l'utilisateur a accès à cette page
    if (allowedRoles.includes(currentUserRole)) {
      setHasAccess(true)
    } else {
      // Rediriger vers la page appropriée selon le rôle
      switch (currentUserRole) {
        case "Encodeur":
          router.push("/encodeur")
          break
        case "Chef_Centre":
          router.push("/chef-centre")
          break
        case "Chef_Division":
          router.push("/chef-division")
          break
        case "Direction":
          router.push("/direction")
          break
        default:
          router.push("/")
      }
    }
  }, [currentUserRole, allowedRoles, router])

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Accès Restreint</h2>
          <p className="text-gray-600">Vous n'avez pas les permissions nécessaires pour accéder à cette page.</p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
